package com.example.englishchat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_VOICE = 1;
    private WebView w;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        w.setWebViewClient(new WebViewClient());
        w.addJavascriptInterface(new Bridge(), "Android");
        tts = new TextToSpeech(this, this);
        w.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int r = tts.setLanguage(Locale.UK);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                r = tts.setLanguage(Locale.US);
            }
            tts.setSpeechRate(0.9f);
            ttsReady = true;
        } else {
            ttsReady = false;
        }
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            public void run() { w.evaluateJavascript(code, null); }
        });
    }

    public class Bridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (tts == null || !ttsReady) {
                        w.evaluateJavascript("window.onTtsError&&onTtsError()", null);
                        return;
                    }
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u");
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(new Runnable() {
                public void run() { if (tts != null) tts.stop(); }
            });
        }

        @JavascriptInterface
        public void listen() {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
                        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "请说英文");
                        startActivityForResult(i, REQ_VOICE);
                    } catch (Exception e) {
                        w.evaluateJavascript("window.onVoiceError&&onVoiceError('none')", null);
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VOICE) {
            if (res == RESULT_OK && data != null) {
                ArrayList<String> a = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (a != null && !a.isEmpty()) {
                    js("window.onVoice(" + JSONObject.quote(a.get(0)) + ")");
                    return;
                }
            }
            js("window.onVoiceError&&onVoiceError('fail')");
        }
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
